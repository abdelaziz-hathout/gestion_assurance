<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Page Constant</title>
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/style.css">
    
    </head>
       <body>
  
           <?php   include("menu.php"); ?>

           
        
           
           
         <!-- intégrer notre panneau aux milieu de la page !-->
         <div class="container">
        <!-- panneau de recherche-->  
            <div class="panel panel-success margetop"> 
       <!-- intégrer la partie de recherche !-->
            <div class="panel-heading">Chercher des Affaires</div>
        <!--intégrer le contenu de recherche !-->
              <div class="panel-body">Le contenu</div>
             </div>

     <!--------------------------------------------------------- -->

        <!-- panneau du contenu de l'interface-->
             <div class="panel panel-primary "> 
      
            <div class="panel-heading">Liste des Affaires</div>
    
              <div class="panel-body">Le Tableau des Affaires</div>
             </div>

        </div>
        

       </body>



 </html>