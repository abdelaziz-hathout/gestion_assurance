    <?php
     // connecter a la bd avec l'instance de l'objet $pdo
        require_once("connexion.php");

        
       $size=isset($_GET['size'] ) ?$_GET['size']: 3;     //nbr limite qui affiche dans la page
        $page=isset($_GET['page'] ) ?$_GET['page']: 1;
        $offset= ($page-1)*$size ;  //nbr de sauter
//récuperer une parametre envoyer par la methode GET
      if(isset($_GET['cin']))
    $cinClient= $_GET['cin'];
    else
    $cinClient="";

      $requet =  "SELECT * FROM clients where cin like'%$cinClient%'
       limit $size 
      offset $offset";
      $requetCount="SELECT count(*) countC from clients where cin like'%$cinClient%'";
      //la fct query() pour execut la requet SELECT
     
    
        $resultatClient = $pdo -> query($requet) ;  
        $resultatCount =$pdo -> query($requetCount) ;
        $tabCount=  $resultatCount->fetch();
        $nbrClient= $tabCount['countC'];
        $rest= $nbrClient%$size;  //rest de la division 
         if($rest===0)
          $nbrPage=$nbrClient / $size;
          else
          $nbrPage= floor($nbrClient / $size) +1; //la partie reel plus 1
          
     
      ?>
 

<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Gestion des clients</title>
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     
    <!--  <link rel="stylesheet" href="../fonts/bootstrap.min.css"> -->
    </head>
       <body>
           

           <?php
            include("menu.php");
             ?>
        <!-- intégrer notre panneau aux milieu de la page !-->
         <div class="container ">
        <!-- panneau de recherche-->  
            <div class="panel panel-danger margetop"> 
       <!-- intégrer la partie de recherche !-->
    
            <div class="panel-heading">
            
               Chercher et Ajouter des clients
             </div>
        <!--intégrer le contenu de recherche !-->
              <div class="panel-body">
                <form method="get" action="clients.php" class="form-inline">
                 <div class="form-group">
              
                  <input type="text "
                   name="cin"
                    placeholder="Taper un CIN" 
                    class="form-control"
                    value="<?php echo $cinClient ?>">
                </div>
                &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp
                  <button type="submit" class="btn btn-success" value="Chercher">
                    <span class="glyphicon glyphicon-search"></span> 
                     Chercher
                      </button>
                      &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp 
                        <a href="nouvelleClient.php">
                         <span class="glyphicon glyphicon-plus"></span>
                            AjoutClient
                        </a>
                </form>
             </div>
          </div>
     <!--------------------------------------------------------- -->

        <!-- panneau du contenu de l'interface-->
       
             <div class="panel panel-primary "> 
      
            <div class="panel-heading">Liste des clients  [<?php echo $nbrClient ?>  Clients] </div>
            
              <div class="panel-body ">
     
                <table class="table table-striped table-bordered  ">
                  <thead >
                   <tr>
                    <th>Id</th> <th>Nom</th>  <th>CIN</th>  <th>Contact</th>  <th>Adress</th> <th>Ville</th>    
                    <th>Cp</th>  <th>Tel</th> <th>Fax</th> <th>Ice</th> <th>Email</th><th>Activite</th>
                    <th>Obs</th>  <th>Pays</th> <th>Monda</th> <th>Action</th>
                                   
                   </tr>
                  </thead>
                  <tbody>
                    <?php while($client = $resultatClient->fetch()) { ?>
                       
                    <!--code Html pour remplier le tab-->
                          <tr>
                            <td> <?php echo $client['id'] ?> </td>
                            <td> <?php echo $client['nom'] ?> </td>
                            <td> <?php echo $client['cin'] ?> </td>
                            <td> <?php echo $client['contact'] ?> </td>
                            <td> <?php echo $client['adresse'] ?> </td>
                            <td> <?php echo $client['ville'] ?> </td>
                            <td> <?php echo $client['cp'] ?> </td>
                            <td> <?php echo $client['tel'] ?> </td>
                            <td> <?php echo $client['fax'] ?> </td>
                            <td> <?php echo $client['ice'] ?> </td>
                            <td> <?php echo $client['mail'] ?> </td>
                            <td> <?php echo $client['activite'] ?> </td>
                            <td> <?php echo $client['obs'] ?> </td>
                            <td> <?php echo $client['pays'] ?> </td>
                            <td> <?php echo $client['mandataire'] ?> </td>
                            <td>
                            <a href="editerClient.php?id=<?php echo $client['id'] ?>"> <span class="glyphicon glyphicon-edit"></span></a> 
                              &nbsp
                         <a onclick="return confirm('vous etes sur de supp?')"
                          href="supprimerClient.php?id=<?php echo $client['id'] ?>">  <span class="glyphicon glyphicon-trash"></span></a>
                           </td>
                          </tr>
                          <?php  } ?>

                  </tbody>
                </table>
                    <div >
                       <ul class="pagination pagination-lg">
                        <?php
                        for($i=1;$i<=$nbrPage;$i++){ ?>
                          
                         <li class="<?php if($i == $page) echo'active' ?>"> <a href="clients.php ?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

                       <?php   } ?>
                                          


                   
                        </ul>
                    </div>
                
               </div>
           </div>
     </div>
  
 </body>
       


<footer>
  

<?php
            include("footer.php");
             ?>
</footer>


 </html>