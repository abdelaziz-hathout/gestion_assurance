  <!-- créer une connexion a la bese de donnee + gérer les exception--> 
<?php
        try{
            $pdo = new PDO("mysql:host=localhost;dbname=gestion_assurance","root","");
        }catch(exception $e){
            die('une Erreur de connexion!' .  $e->getMessage());
        }
        
?>