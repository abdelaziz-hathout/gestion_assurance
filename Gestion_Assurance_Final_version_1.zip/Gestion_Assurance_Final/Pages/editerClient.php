
<?php

require_once('connexion.php');
$id=isset($_GET['id'])?$_GET['id']:0;
$requete="select * from clients where id=$id";
$resultat=$pdo->query($requete);
$client=$resultat->fetch();

$nom=$client['nom'];
$cin=$client['cin'];
$contact=$client['contact'];
$adresse=$client['adresse'];
$ville=$client['ville'];
$cp=$client['cp'];
$tel=$client['tel'];
$fax=$client['fax'];
$ice=$client['ice'];
$mail=$client['mail'];
$activite=$client['activite'];
$obs=$client['obs'];
$pays=$client['pays'];
$mandataire=$client['mandataire'];

?>

<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Edition d'un client</title>
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/style.css">
    
    </head>
       <body>
  
           <?php   include("menu.php"); ?>

        
         <div class="container">
       
    
     
         <div class="panel panel-primary "> 
      
            <div class="panel-heading"> Edition du client</div>
    
              <div class="panel-body">
                  

              <form method="post" action="updateClients.php" class="form">
                          <div class="form-group col-md-6 ">
                         <label for="id">Id: <?php echo $id?></label>
                         </div>
                         <div class="form-group col-md-6  invisible">
                           <input type="hidden "
                            name="id"
                              placeholder="Taper un id" 
                                class="form-control"
                              value="<?php echo $id?> "/>
                                 </div>
                 <div class="form-group col-md-6">
                   <label for="nom">Nom:</label>
                    <input type="text "
                      name="nom"
                        placeholder="Taper un Nom" 
                          class="form-control"
                          value="<?php echo $nom?> "/>
                          
                          <label for="cin">Cin:</label>
                    <input type="text "
                      name="cin"
                        placeholder="Taper un Cin" 
                          class="form-control"
                          value="<?php echo $cin?> "/>

                          <label for="contact">Contact:</label>
                    <input type="text "
                      name="contact"
                        placeholder="Taper un Contact" 
                          class="form-control"
                          value="<?php echo $contact?> "/>
                          
                          <label for="adresse">Adresse:</label>
                    <input type="text "
                      name="adresse"
                        placeholder="Taper un adr" 
                          class="form-control"
                          value="<?php echo $adresse?> "/>

                    <label for="ville">Ville:</label>
                    <input type="text "
                      name="ville"
                        placeholder="Taper un ville" 
                          class="form-control"
                          value="<?php echo $ville?> "/>
                          <label for="cp">Cp:</label>
                    <input type="text "
                      name="cp"
                        placeholder="Taper un cp" 
                          class="form-control"
                          value="<?php echo $cp?> "/>
                          <label for="tel">Tel:</label>
                    <input type="text "
                      name="tel"
                        placeholder="Taper un tel" 
                          class="form-control"
                          value="<?php echo $tel?> "/>
                          
                </div>



                <div class="form-group col-md-6">
                   <label for="fax">Fax:</label>
                    <input type="text "
                      name="fax"
                        placeholder="Taper un fax" 
                          class="form-control"
                          value="<?php echo $fax?> "/>
                          
                          <label for="ice">Ice:</label>
                    <input type="text "
                      name="ice"
                        placeholder="Taper un Ice" 
                          class="form-control"
                          value="<?php echo $ice?> "/>
                          <label for="mail">Email:</label>
                    <input type="text "
                      name="mail"
                        placeholder="Taper un Email" 
                          class="form-control"
                          value="<?php echo $mail?> "/>
                          <label for="activite">Activite:</label>
                    <input type="text "
                      name="activite"
                        placeholder="Taper un Activite" 
                          class="form-control"
                          value="<?php echo $activite?> "/>
                          <label for="ops">Obs:</label>
                    <input type="text "
                      name="obs"
                        placeholder="Taper un Obs" 
                          class="form-control"
                          value="<?php echo $obs?> "/>
                          <label for="pays">Pays:</label>
                    <input type="text "
                      name="pays"
                        placeholder="Taper un Pays" 
                          class="form-control"
                          value="<?php echo $pays?> "/>
                          <label for="mandataire">Mandataire:</label>
                    <input type="number "
                      name="mandataire"
                        placeholder="Taper un Manda" 
                          class="form-control"
                          value="<?php echo $mandataire?> "/>


                   
                </div>


                         <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-success" value="save">
                    <span class="glyphicon glyphicon-save"></span> 
                    Update
                      </button>
                      </div>
                </form>
              </div>
             </div>

        </div>
        

       </body>

<footer>
  
<?php
            include("footer.php");
             ?>
</footer>

 </html> 