
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <footer class="text-center text-white" style="background-color: gris;">

  <div class="text-center text-dark p-3" style="background-color: rgba(0, 0, 0, 0.2);">
  <i class="fa fa-car"></i>    &nbsp &nbsp &nbsp &nbsp  © 2021 Copyright:
    <a class="text-dark" href="https://Moritsoft.com/">Moritsoft.com</a>
 
    
    <br>
    <i class="fa fa-info"></i>    &nbsp &nbsp &nbsp &nbsp   Gmail:
    <a class="text-succes" href="#">MORITSOFT@gmail.com</a>
    
  </div>
  <!-- Copyright -->
</footer>