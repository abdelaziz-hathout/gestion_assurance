<?php
 // if(isset($_POST['save']))
require_once('connexion.php');


 if(isset($_POST['nom']))
    $nom=$_POST['nom'];
  
 if(isset($_POST['cin']))
 $cin=$_POST['cin'];

if(isset($_POST['contact']))
$contact=$_POST['contact'] ;

 if(isset($_POST['adresse']))
 $adresse=$_POST['adresse'];

if(isset($_POST['ville']))
$ville=$_POST['ville'];

 if(isset($_POST['cp']))
 $cp=$_POST['cp'];

if(isset($_POST['tel']))
$tel= $_POST['tel'];

if(isset($_POST['fax']))
$fax=$_POST['fax'];

 if(isset($_POST['ice']))
 $ice=$_POST['ice'];

if(isset($_POST['mail']))
$mail=$_POST['mail'] ;

if(isset($_POST['activite']))
$activite=$_POST['activite'];

if(isset($_POST['obs']))
$obs=$_POST['obs'];

if(isset($_POST['pays']))
$pays=$_POST['pays'];

if(isset($_POST['mandataire']))
$mandataire=$_POST['mandataire'];
   
 $requete=" insert into clients values ('',$nom,$cin, $contact, $adresse,$ville, $cp, $tel,$fax, $ice, $mail, $activite, $obs, $pays, $mandataire)";

 $resultat=$pdo->prepare($requete);
 $resultat->execute($requete);

 header('location:clients.php');

?>