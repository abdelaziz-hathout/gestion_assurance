    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
 <style>
 .dropdown{
   margin-top:10px;
   margin-left:90px;
  
 }
 
 </style>

            <nav class="navbar  navbar-inverse  navebar-fixed-top">
              <div class="container-fluid   " >
                <div class="navbar-header ">
                 <a href="../index.php" class="navbar-brand">Gestion d'assurance</a>
                </div>
               
               <ul class="nav navbar-nav col-md-10">


               <div class="dropdown col-md-2">      
    <button class="btn btn-link dropdown-toggle" type="button" data-toggle="dropdown">Personne
    <span class="caret"></span></button>
    <ul class="dropdown-menu">
      <li><a href="clients.php">clients</a></li>
      <li><a href="mandataires.php">mandataires</a></li>
    </ul>
           </div>
                
                   <li><a href="vehicules.php">vehicules</a></li>
                   <li><a href="affaires.php">affaires</a></li>
                   <li><a href="reglement.php">reglement</a></li>
                   <li><a href="etat.php">etat</a></li>
                   <li><a href="parametre.php">parametre</a></li>
                  
               </ul>
               </div>
              </div>


              
            </nav>

