<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Nouvelle client</title>
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/style.css">
    
    </head>
       <body>
  
           <?php   include("menu.php"); ?>

        
         <div class="container">
       
    
     
         <div class="panel panel-primary "> 
      
            <div class="panel-heading">Saisir les données du client</div>
    
              <div class="panel-body">
                  

              <form method="post" action="insertClients.php" class="form">
                 <div class="form-group col-md-6">
                   <label for="nom">Nom:</label>
                    <input type="text "
                      name="nom" required
                        placeholder="Taper un Nom" 
                          class="form-control"/>
                          
                          <label for="cin">Cin:</label>
                    <input type="text "
                      name="cin"  required
                        placeholder="Taper un Cin" 
                          class="form-control"/>

                          <label for="contact">Contact:</label>
                    <input type="text "
                      name="contact"  required
                        placeholder="Taper un Contact" 
                          class="form-control"/>
                          
                          <label for="adresse">Adresse:</label>
                    <input type="text "
                      name="adresse"    required
                        placeholder="Taper un adr" 
                          class="form-control"/>

                    <label for="ville">Ville:</label>
                    <input type="text "
                      name="ville"     required
                        placeholder="Taper un ville" 
                          class="form-control"/>
                          <label for="cp">Cp:</label>
                    <input type="text "
                      name="cp"      required
                        placeholder="Taper un cp" 
                          class="form-control"/>
                          <label for="tel">Tel:</label>
                    <input type="text "
                      name="tel"     required
                        placeholder="Taper un tel" 
                          class="form-control"/>
                          
                </div>



                <div class="form-group col-md-6">
                   <label for="fax">Fax:</label>
                    <input type="text "
                      name="fax"         required
                        placeholder="Taper un fax" 
                          class="form-control"/>
                          
                          <label for="ice">Ice:</label>
                    <input type="text "
                      name="ice"       required
                        placeholder="Taper un Ice" 
                          class="form-control"/>
                          <label for="mail">Email:</label>
                    <input type="text "
                      name="mail"      required
                        placeholder="Taper un Email" 
                          class="form-control"/>
                          <label for="activite">Activite:</label>
                    <input type="text "
                      name="activite"    required
                        placeholder="Taper un Activite" 
                          class="form-control"/>
                          <label for="ops">Obs:</label>
                    <input type="text "
                      name="obs"       required
                        placeholder="Taper un Obs" 
                          class="form-control"/>
                          <label for="pays">Pays:</label>
                    <input type="text "
                      name="pays"          required
                        placeholder="Taper un Pays" 
                          class="form-control"/>
                          <label for="mandataire">Mandataire:</label>
                    <input type="number "
                      name="mandataire"           required
                        placeholder="Taper un Manda" 
                          class="form-control"/>


                   
                </div>


                         <div class="form-group col-md-8">
                  <button type="submit" name="save" class="btn btn-success" value="save">
                    <span class="glyphicon glyphicon-save"></span> 
                    Save
                      </button>
                      </div>
                </form>
              </div>
             </div>

        </div>
        

       </body>

<footer>
  
<?php
            include("footer.php");
             ?>
</footer>

 </html> 