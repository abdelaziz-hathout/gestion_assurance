<?php
   require_once('connexion.php');

   $id=isset($_GET['id'])?$GET['id']:0;

     
   $requete=" DELETE FROM clients WHERE id= $id";

   $resultat=$pdo->prepare($requete);
   $resultat->execute($resultat);
  
   header('location:clients.php');



?>