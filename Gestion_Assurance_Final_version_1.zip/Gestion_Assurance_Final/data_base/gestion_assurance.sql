
DROP DATABASE IF EXISTS gestion_assurance;
----------------
    CREATE DATABASE IF NOT EXISTS gestion_assurance;
---------------
      USE gestion_assurance;
---------------------------------
        CREATE TABLE IF NOT EXISTS `affaires` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `date` date NOT NULL,
        `time` time NOT NULL,
        `compagnie` int(11) NOT NULL,
        `police` varchar(100) NOT NULL,
        `provision` int(11) NOT NULL,
        `type` int(11) NOT NULL,
        `ferme` int(11) NOT NULL,
        `client` int(11) NOT NULL,
        `risque` int(11) NOT NULL,
        `production` decimal(14,2) NOT NULL,
        `fraction` int(11) NOT NULL,
        `duree` int(11) NOT NULL,
        `datei` datetime NOT NULL,
        `datef` datetime NOT NULL,
        `solde` decimal(14,2) NOT NULL,
        `obs` varchar(1000) NOT NULL,
        `etat` int(11) NOT NULL,
        `op` varchar(100) NOT NULL,
        PRIMARY KEY (`id`)
        );

--------------------------------------------------------

                        CREATE TABLE IF NOT EXISTS `clients` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `nom` varchar(500) COLLATE utf8_bin NOT NULL,
                `cin` varchar(100) COLLATE utf8_bin NOT NULL,
                `contact` varchar(500) COLLATE utf8_bin NOT NULL,
                `adresse` varchar(500) COLLATE utf8_bin NOT NULL,
                `ville` varchar(50) COLLATE utf8_bin NOT NULL,
                `cp` varchar(50) COLLATE utf8_bin NOT NULL,
                `tel` varchar(50) COLLATE utf8_bin NOT NULL,
                `fax` varchar(50) COLLATE utf8_bin NOT NULL,
                `ice` varchar(50) COLLATE utf8_bin NOT NULL,
                `mail` varchar(50) COLLATE utf8_bin NOT NULL,
                `activite` varchar(300) COLLATE utf8_bin NOT NULL,
                `obs` varchar(500) COLLATE utf8_bin NOT NULL,
                `pays` varchar(50) COLLATE utf8_bin NOT NULL,
                 `mandataire` int(50)  NOT NULL,
                PRIMARY KEY (`id`)
                );
-------------------------------------------------------------

                        CREATE TABLE IF NOT EXISTS `mandataires` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `nom` varchar(500) COLLATE utf8_bin NOT NULL,
                `cin` varchar(100) COLLATE utf8_bin NOT NULL,
                `adresse` varchar(500) COLLATE utf8_bin NOT NULL,
                `ville` varchar(50) COLLATE utf8_bin NOT NULL,
                `cp` varchar(50) COLLATE utf8_bin NOT NULL,
                `tel` varchar(50) COLLATE utf8_bin NOT NULL,
                `ice` varchar(50) COLLATE utf8_bin NOT NULL,
                `mail` varchar(50) COLLATE utf8_bin NOT NULL,
                `activite` varchar(300) COLLATE utf8_bin NOT NULL,
                `obs` varchar(500) COLLATE utf8_bin NOT NULL,
                PRIMARY KEY (`id`)
                );
                -------------------------------

    CREATE TABLE IF NOT EXISTS `compagnies` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `nom` varchar(500) NOT NULL,
    `adresse` varchar(1000) NOT NULL,
    `cp` varchar(50) NOT NULL,
    `ville` varchar(50) NOT NULL,
    `tel` varchar(100) NOT NULL,
    `fax` varchar(50) NOT NULL,
    `mail` varchar(100) NOT NULL,
    PRIMARY KEY (`id`)
    );
----------------------------------------------------------




-----------------------------------
CREATE TABLE IF NOT EXISTS `fractions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `affaire` int(11) NOT NULL,
  `montant` decimal(10,0) NOT NULL,
  `date_effet` date NOT NULL,
  `date_reg` date NOT NULL,
  `solde` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`)
);

------------------------------
        CREATE TABLE IF NOT EXISTS `provisions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `ref` varchar(100) NOT NULL,
        `affaire` int(11) NOT NULL,
        `etat` int(1) NOT NULL,
        PRIMARY KEY (`id`)
        );
-------------------------
CREATE TABLE IF NOT EXISTS `reglement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fraction` int(11) NOT NULL,
  `montant` decimal(14,2) NOT NULL,
  `date` date NOT NULL,
  `mode` int(1) NOT NULL,
  `ref` varchar(500) NOT NULL,
  `validation` int(1) NOT NULL,
  PRIMARY KEY (`id`)
);


-------------------------
            CREATE TABLE IF NOT EXISTS `risque` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `marque` varchar(500) NOT NULL,
            `matricule` varchar(500) NOT NULL,
            PRIMARY KEY (`id`)
            ) ;

------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` int(2) NOT NULL,
  `ma` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
);


----------------------------------------------add FOREIGN KEY---------------------------

    ALTER TABLE reglement ADD CONSTRAINT fk_1 FOREIGN KEY (fraction) REFERENCES fractions (id);
    ALTER TABLE fractions ADD CONSTRAINT fk_2 FOREIGN KEY (affaire) REFERENCES affaires (id);
   
    ALTER TABLE affaires ADD CONSTRAINT fk_4 FOREIGN KEY (compagnie) REFERENCES compagnies (id);
    ALTER TABLE affaires ADD CONSTRAINT fk_5 FOREIGN KEY (client) REFERENCES clients (id);
    ALTER TABLE affaires ADD CONSTRAINT fk_6 FOREIGN KEY (risque) REFERENCES risque (id);
    ALTER TABLE affaires ADD CONSTRAINT fk_7 FOREIGN KEY (fraction) REFERENCES fractions (id);
    ALTER TABLE affaires ADD CONSTRAINT fk_10 FOREIGN KEY (provision) REFERENCES provisions (id);

     ALTER TABLE clients ADD CONSTRAINT fk_11 FOREIGN KEY (mandataire) REFERENCES mandataires (id);

    ALTER TABLE provisions ADD CONSTRAINT fk_9 FOREIGN KEY (affaire) REFERENCES affaires (id);


----------------------------Insert In tables-------------------
-------------clients-------------------------------------------------
INSERT INTO clients(nom,cin,contact,adresse,ville,cp,tel,fax,ice,mail,activite,obs,pays,mandataire)VALUES
('abdo','LA121','','akiod','marrakech','4400','0615919437','0506070809','ice3','az@gmail.com','stagaire','obs3','maroc',1),
('karim','SO1','','mhamid2','marrakech','4000','0655667788','0512345678','ice4','mt@gmail.com','chef','obs4','maroc',2);

SELECT * FROM clients;

--------------------------------------------------------------
INSERT INTO mandataires(id,nom,cin,adresse,ville,cp,tel,ice,mail,activite,obs)VALUES
(1,'abdo','HA2536','GUELIZ','marrakech','4400','0605956437','ice3','AB@gmail.com','docteur','obs3'),
(2,'kitea','H1214','MASSIRA','marrakech','4400','0755667758','ice4','KT@gmail.com','entreprise','obs4');