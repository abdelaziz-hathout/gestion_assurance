<?php
  header("location:Pages/clients.php")
?>